

package analisadorsintatico;

import java.util.HashMap;
import java.util.Map;


public class TabelaSintatica {

    public Map<String, Map<String, Integer>> gerarTabelaSintatica() {

        Map<String, Map<String, Integer>> tabelaSintatica = new HashMap<>();

        Map<String, Integer> tabelaProducoes_inicio = new HashMap<>();
        tabelaProducoes_inicio.put("PROGRAMA", 0);
        tabelaSintatica.put("inicio", tabelaProducoes_inicio);

        Map<String, Integer> tabelaProducoes_fim = new HashMap<>();
        tabelaProducoes_fim.put("LISTACOMANDOS", 2);
        tabelaSintatica.put("fim", tabelaProducoes_fim);

        Map<String, Integer> tabelaProducoes_declaraint = new HashMap<>();
        tabelaProducoes_declaraint.put("LISTACOMANDOS", 1);
        tabelaProducoes_declaraint.put("COMANDO", 6);
        tabelaProducoes_declaraint.put("DECLARACAO", 37);
        tabelaSintatica.put("declaraint", tabelaProducoes_declaraint);

        Map<String, Integer> tabelaProducoes_escreva = new HashMap<>();
        tabelaProducoes_escreva.put("LISTACOMANDOS", 1);
        tabelaProducoes_escreva.put("COMANDO", 3);
        tabelaProducoes_escreva.put("ESCREVA", 26);
        tabelaSintatica.put("escreva", tabelaProducoes_escreva);

        Map<String, Integer> tabelaProducoes_leia = new HashMap<>();
        tabelaProducoes_leia.put("LISTACOMANDOS", 1);
        tabelaProducoes_leia.put("COMANDO", 4);
        tabelaProducoes_leia.put("LEITURA", 5);
        tabelaProducoes_leia.put("LEIA", 25);
        tabelaSintatica.put("leia", tabelaProducoes_leia);

        Map<String, Integer> tabelaProducoes_se = new HashMap<>();
        tabelaProducoes_se.put("LISTACOMANDOS", 1);
        tabelaProducoes_se.put("COMANDO", 13);
        tabelaProducoes_se.put("SE", 27);
        tabelaSintatica.put("se", tabelaProducoes_se);
        
        Map<String, Integer> tabelaProducoes_senao = new HashMap<>();
        tabelaProducoes_senao.put("LISTACOMANDOS", 2);
        tabelaProducoes_senao.put("SENAO", 14);
        tabelaSintatica.put("senao", tabelaProducoes_senao);
        
        Map<String, Integer> tabelaProducoes_fimse = new HashMap<>();
        tabelaProducoes_fimse.put("LISTACOMANDOS", 2);
        tabelaProducoes_fimse.put("FIMSE", 15);
        tabelaSintatica.put("fimse", tabelaProducoes_fimse);
        
        Map<String, Integer> tabelaProducoes_faca = new HashMap<>();
        tabelaProducoes_faca.put("LISTACOMANDOS", 1);
        tabelaProducoes_faca.put("COMANDO", 16);
        tabelaProducoes_faca.put("FACA", 28);
        tabelaSintatica.put("faca", tabelaProducoes_faca);
        
        Map<String, Integer> tabelaProducoes_ate = new HashMap<>();
        tabelaProducoes_ate.put("ATE", 29);
        tabelaSintatica.put("ate", tabelaProducoes_ate);

        Map<String, Integer> tabelaProducoes_maior = new HashMap<>();
        tabelaProducoes_maior.put("OPERADORLOG", 38);
        tabelaProducoes_maior.put("CONTEUDOEXPRESSAOLOG", 18);
        tabelaSintatica.put("maior", tabelaProducoes_maior);
        
        Map<String, Integer> tabelaProducoes_menor = new HashMap<>();
        tabelaProducoes_menor.put("OPERADORLOG", 39);
        tabelaProducoes_menor.put("CONTEUDOEXPRESSAOLOG", 18);
        tabelaSintatica.put("menor", tabelaProducoes_menor);
        
        Map<String, Integer> tabelaProducoes_maiorigual = new HashMap<>();
        tabelaProducoes_maiorigual.put("OPERADORLOG", 40);
        tabelaProducoes_maiorigual.put("CONTEUDOEXPRESSAOLOG", 18);
        tabelaSintatica.put("maiorigual", tabelaProducoes_maiorigual);
        
        Map<String, Integer> tabelaProducoes_menorigual = new HashMap<>();
        tabelaProducoes_menorigual.put("OPERADORLOG", 41);
        tabelaProducoes_menorigual.put("CONTEUDOEXPRESSAOLOG", 18);
        tabelaSintatica.put("menorigual", tabelaProducoes_menorigual);
        
        Map<String, Integer> tabelaProducoes_igual = new HashMap<>();
        tabelaProducoes_igual.put("OPERADORLOG", 42);
        tabelaProducoes_igual.put("CONTEUDOEXPRESSAOLOG", 18);
        tabelaSintatica.put("igual", tabelaProducoes_igual);
        
        Map<String, Integer> tabelaProducoes_diferente = new HashMap<>();
        tabelaProducoes_diferente.put("OPERADORLOG", 43);
        tabelaProducoes_diferente.put("CONTEUDOEXPRESSAOLOG", 18);
        tabelaSintatica.put("diferente", tabelaProducoes_diferente);
        
        Map<String, Integer> tabelaProducoes_atribuicao = new HashMap<>();
        tabelaProducoes_atribuicao.put("ATRIBUICAO", 12);
        tabelaProducoes_atribuicao.put("CONTEUDODECLARACAO", 8);
        tabelaSintatica.put("atribuicao", tabelaProducoes_atribuicao);
        
        Map<String, Integer> tabelaProducoes_fimlinha = new HashMap<>();
        tabelaProducoes_fimlinha.put("CONTEUDODECLARACAO", 11);
        tabelaProducoes_fimlinha.put("CONTEUDOEXPRESSAOMAT", 22);
        tabelaProducoes_fimlinha.put("CONTEUDOEXPRESSAOLOG", 19);
        tabelaSintatica.put("fimlinha", tabelaProducoes_fimlinha);
        
        Map<String, Integer> tabelaProducoes_fechaparenteses = new HashMap<>();
        tabelaProducoes_fechaparenteses.put("LISTACOMANDOS", 2);
        tabelaProducoes_fechaparenteses.put("CONTEUDOEXPRESSAOLOG", 19);
        tabelaSintatica.put("fechaparenteses", tabelaProducoes_fechaparenteses);
        
        Map<String, Integer> tabelaProducoes_soma = new HashMap<>();
        tabelaProducoes_soma.put("OPERADORMAT", 44);
        tabelaProducoes_soma.put("CONTEUDOEXPRESSAOMAT", 21);
        tabelaSintatica.put("soma", tabelaProducoes_soma);
        
        Map<String, Integer> tabelaProducoes_subtracao = new HashMap<>();
        tabelaProducoes_subtracao.put("OPERADORMAT", 45);
        tabelaProducoes_subtracao.put("CONTEUDOEXPRESSAOMAT", 21);
        tabelaSintatica.put("subtracao", tabelaProducoes_subtracao);
        
        Map<String, Integer> tabelaProducoes_multiplicacao = new HashMap<>();
        tabelaProducoes_multiplicacao.put("OPERADORMAT", 46);
        tabelaProducoes_multiplicacao.put("CONTEUDOEXPRESSAOMAT", 21);
        tabelaSintatica.put("multiplicacao", tabelaProducoes_multiplicacao);
        
        Map<String, Integer> tabelaProducoes_divisao = new HashMap<>();
        tabelaProducoes_divisao.put("OPERADORMAT", 47);
        tabelaProducoes_divisao.put("CONTEUDOEXPRESSAOMAT", 21);
        tabelaSintatica.put("divisao", tabelaProducoes_divisao);
        
        Map<String, Integer> tabelaProducoes_incremento = new HashMap<>();
        tabelaProducoes_incremento.put("ITERACAO", 23);
        tabelaProducoes_incremento.put("CONTEUDODECLARACAO", 10);
        tabelaSintatica.put("incremento", tabelaProducoes_incremento);
        
        Map<String, Integer> tabelaProducoes_decremento = new HashMap<>();
        tabelaProducoes_decremento.put("ITERACAO", 24);
        tabelaProducoes_decremento.put("CONTEUDODECLARACAO", 10);
        tabelaSintatica.put("decremento", tabelaProducoes_decremento);
        
        Map<String, Integer> tabelaProducoes_numerointeiro = new HashMap<>();
        tabelaProducoes_numerointeiro.put("CONTEUDO", 34);
        tabelaProducoes_numerointeiro.put("NUMERO", 31);
        tabelaProducoes_numerointeiro.put("EXPRESSAOMAT", 20);
        tabelaSintatica.put("numerointeiro", tabelaProducoes_numerointeiro);
        
        Map<String, Integer> tabelaProducoes_numerointeironegativo = new HashMap<>();
        tabelaProducoes_numerointeironegativo.put("CONTEUDO", 34);
        tabelaProducoes_numerointeironegativo.put("NUMERO", 32);
        tabelaProducoes_numerointeironegativo.put("EXPRESSAOMAT", 20);
        tabelaSintatica.put("numerointeironegativo", tabelaProducoes_numerointeironegativo);
        
        Map<String, Integer> tabelaProducoes_string = new HashMap<>();
        tabelaProducoes_string.put("CONTEUDO", 36);
        tabelaProducoes_string.put("STRING", 30);
        tabelaProducoes_string.put("EXPRESSAOMAT", 20);
        tabelaSintatica.put("string", tabelaProducoes_string);
        
        Map<String, Integer> tabelaProducoes_variavel = new HashMap<>();
        tabelaProducoes_variavel.put("LISTACOMANDOS", 1);
        tabelaProducoes_variavel.put("COMANDO", 7);
        tabelaProducoes_variavel.put("CONTEUDO", 35);
        tabelaProducoes_variavel.put("VARIAVEL", 33);
        tabelaProducoes_variavel.put("CONTEUDODECLARACAO", 9);
        tabelaProducoes_variavel.put("EXPRESSAOMAT", 20);
        tabelaProducoes_variavel.put("EXPRESSAOLOG", 17);
        tabelaSintatica.put("variavel", tabelaProducoes_variavel);
        
        
        return tabelaSintatica;
        

    }
    

}
