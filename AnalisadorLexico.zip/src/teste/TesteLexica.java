package teste;

import analisadorlexico.Lexica;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class TesteLexica {

    public static void main(String[] args) throws IOException {
        
        
        String caminho = "";
        boolean argumento = false;
        ArrayList<String> listaArgumentos = new ArrayList<>();
        
        if (args.length == 0){
            System.out.println("Argumento vazio");
        } else {
            caminho = args[0];
            
        }
        
        if (args.length > 1){
            for (int x = 1; x < args.length; x++){
                if (args[x].equals("-lt")){
                    argumento = true;
                }
            }
        }
        
        
        abreArquivo(caminho, argumento, listaArgumentos);

    }

    public static void abreArquivo(String caminho, boolean argumento, ArrayList<String> listaArgumentos) throws IOException {

        try {
            String nome;
            
            BufferedReader lerarq = new BufferedReader(new FileReader(caminho));
            
            ArrayList<String> linhas = new ArrayList<>();

            try {
                String linha = lerarq.readLine();

                while (linha != null) {
                    linhas.add(linha);
                    linha = lerarq.readLine();

                }
            } catch (IOException e) {
                System.out.println(e.getMessage());
            }

            Lexica al = new Lexica();
            al.analise(linhas, argumento);

        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
        }

    }

}
